package com.developer.recycler_proj

data class student(val title: String, val description:String){

}